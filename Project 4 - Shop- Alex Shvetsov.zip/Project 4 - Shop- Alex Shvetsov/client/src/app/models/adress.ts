
export class Address{
    public constructor(
    
        public city?: String,
        public street?: String,
        public houseNumber?: Number,
        public entrance?: Number,
        public floor?:Number
      ){}
}