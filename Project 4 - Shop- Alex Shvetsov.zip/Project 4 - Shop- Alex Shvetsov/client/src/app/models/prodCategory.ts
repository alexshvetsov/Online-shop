
export class ProdCategory{
   
    public constructor(
        public _id?:String,
        public name?: String,
      ){}
}