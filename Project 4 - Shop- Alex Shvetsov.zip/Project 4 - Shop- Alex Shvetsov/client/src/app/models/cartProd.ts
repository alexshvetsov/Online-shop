
export class CartProd{
    
    public constructor(
             price?:Number,
            product?:String,
            name?:String,
            quantity?:Number
      ){}
}