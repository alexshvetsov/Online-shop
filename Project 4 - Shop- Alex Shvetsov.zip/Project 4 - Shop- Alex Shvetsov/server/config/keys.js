module.exports ={
    google:{
        clientID:"513717108817-7q3rk1h1c9hf9nk275a46rhpcq7iv2kf.apps.googleusercontent.com",
        clientSecret:"I19UHo6gE-cp1Wl-1Uz_QXya"
    },
    mongodb:{
        dbURI:"mongodb://localhost:27017/ShopDB"
    }
    ,session:{
        cookieKey:"thenetninjastrikesagain"
    }
}